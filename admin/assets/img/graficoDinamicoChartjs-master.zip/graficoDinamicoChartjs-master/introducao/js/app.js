var ctx = document.getElementById("myChart");

var chart = ctx.getContext('2d');

chart.fillStyle = "red";
chart.fillRect(0,0,100,200);

chart.fillStyle = "blue";
chart.fillRect(150, 50, 100, 200);