# Como implementar GRÁFICOS dinâmicos com Chart.js

- Biblioteca chart.js
- PHP (Json)
- JQuery (Ajax)
- MySQL

Código referente a video aula ministrada no Canal do YouTube - Guilherme Chinaglia

### Link YouTube: [Guilherme Chinaglia](https://www.youtube.com/channel/UCEkMd3Bw_bVUuGbXU0sFPSg/featured?view_as=subscriber)

## Se ainda não é inscrito no Canal, se inscreva e ative as notificações para receber novos vídeos toda semana!!

[Instagram - Guilherme Chinaglia](https://www.instagram.com/guilhermechinagliadev/)

@guilhermechinagliadev

Abraço à todos,

Guilherme Chinaglia
